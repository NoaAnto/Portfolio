Este proyecto es una plataforma web para la venta de entradas de musicales de Disney. Permite a los usuarios ver diferentes espectáculos, consultar imágenes de los musicales y seleccionar sus entradas de manera sencilla.

Está desarrollado con HTML, CSS y JavaScript, ofreciendo una interfaz atractiva y funcional. El diseño incluye imágenes representativas de los musicales y efectos dinámicos para mejorar la experiencia del usuario.

Para instalarlo, simplemente extrae los archivos en un servidor local o en una carpeta de tu ordenador y abre el archivo index.html en cualquier navegador web. No requiere configuración adicional. 